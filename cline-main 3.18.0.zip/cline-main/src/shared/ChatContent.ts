export interface ChatContent {
	message?: string
	images?: string[]
	files?: string[]
}
