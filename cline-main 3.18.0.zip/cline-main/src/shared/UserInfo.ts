export interface UserInfo {
	displayName?: string
	email?: string
	photoURL?: string
}
