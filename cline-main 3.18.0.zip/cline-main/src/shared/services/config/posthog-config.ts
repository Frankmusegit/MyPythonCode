// Public PostHog key (safe for open source)
export const posthogConfig = {
	apiKey: "phc_qfOAGxZw2TL5O8p9KYd9ak3bPBFzfjC8fy5L6jNWY7K",
	host: "https://data.cline.bot",
	uiHost: "https://us.posthog.com",
}
