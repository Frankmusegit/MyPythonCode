---
"claude-dev": patch
---

fix: Prevent duplicate BOM
