---
"claude-dev": minor
---

adds a file tracking metadata system that monitors files Cline interacts with, detects user edits, and proactively alerts Cline to re-read files before editing to prevent context issues when diff editing
