---
"@cline/extension": patch
---

Telemetry added for when users click AI-generated options/questions, or if they ignore them. Also tracks the number of options that were displayed.
