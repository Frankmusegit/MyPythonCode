---
"claude-dev": patch
---

convert inline style to tailwind css of file `WelcomeView.tsx`
