---
"claude-dev": minor
---

Add import path aliasing to the webview
