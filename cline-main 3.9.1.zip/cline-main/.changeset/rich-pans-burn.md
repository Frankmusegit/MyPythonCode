---
"claude-dev": minor
---

Moved file mention searching from the webview to the backend, using ripgrep for faster searching. Added scoring logic to sort and exlcude results based on relevance. "Searching" indicator added for long-running file searches on older hardware.
