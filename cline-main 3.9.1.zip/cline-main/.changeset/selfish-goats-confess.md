---
"claude-dev": patch
---

adding gemini 2.5 pro preview
