---
"claude-dev": minor
---

Add Support for Bytedance Doubao
