---
"claude-dev": patch
---

make ServerRow not optionally not expandable
