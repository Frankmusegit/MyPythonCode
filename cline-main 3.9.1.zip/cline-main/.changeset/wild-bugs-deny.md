---
"claude-dev": patch
---

Update import aliases in webview
