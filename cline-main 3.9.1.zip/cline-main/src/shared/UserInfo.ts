export interface UserInfo {
	displayName: string | null
	email: string | null
	photoURL: string | null
}
