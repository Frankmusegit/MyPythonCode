export function secondsToMs(seconds: number): number {
	return seconds * 1000
}
